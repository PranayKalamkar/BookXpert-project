// src/contexts/EmployeeContext.tsx
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Employee } from '../types/employee';
import { getEmployees, addEmployee, updateEmployee, deleteEmployee, deleteMultiple } from '../utils/mockData';

interface EmployeeContextType {
  employees: Employee[];
  add: (emp: Omit<Employee, 'id'>) => void;
  update: (id: number, updates: Partial<Employee>) => void;
  remove: (id: number) => void;
  removeMultiple: (ids: number[]) => void;
  load: () => void;
}

const EmployeeContext = createContext<EmployeeContextType | undefined>(undefined);

export const useEmployees = () => {
  const context = useContext(EmployeeContext);
  if (!context) throw new Error('useEmployees must be used within EmployeeProvider');
  return context;
};

interface Props { children: ReactNode; }
export const EmployeeProvider: React.FC<Props> = ({ children }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);

  useEffect(() => {
    load();
  }, []);

  const load = () => {
    setEmployees(getEmployees());
  };

  const add = (emp: Omit<Employee, 'id'>) => {
    addEmployee(emp);
    load();
  };

  const update = (id: number, updates: Partial<Employee>) => {
    updateEmployee(id, updates);
    load();
  };

  const remove = (id: number) => {
    deleteEmployee(id);
    load();
  };

  const removeMultiple = (ids: number[]) => {
    deleteMultiple(ids);
    load();
  };

  return (
    <EmployeeContext.Provider value={{ employees, add, update, remove, removeMultiple, load }}>
      {children}
    </EmployeeContext.Provider>
  );
};