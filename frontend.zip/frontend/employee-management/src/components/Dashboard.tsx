// src/components/Dashboard.tsx
import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { AppBar, Toolbar, Typography, Button, Container } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import EmployeeList from './EmployeeList';
import Report from './Report';

const Dashboard: React.FC = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>Employee Management</Typography>
          <Button color="inherit" onClick={() => { logout(); navigate('/login'); }}>Logout</Button>
          <Button color="inherit" onClick={() => navigate('/reports')}>Reports</Button>
        </Toolbar>
      </AppBar>
      <Container sx={{ mt: 4 }}>
        <EmployeeList />
        <Report />
      </Container>
    </>
  );
};

export default Dashboard;