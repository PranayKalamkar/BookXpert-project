// src/components/EmployeeList.tsx
import React, { useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useEmployees } from '../contexts/EmployeeContext';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Checkbox,
  Collapse,
  Box,
  Typography,
  FormHelperText,
} from '@mui/material';
import { Edit, Delete, Add, Close, ExpandMore, ExpandLess } from '@mui/icons-material';
import { Employee } from '../types/employee';

// Validation schema
const schema = yup.object().shape({
  name: yup.string().required('Name is required'),
  email: yup.string().email('Invalid email').required('Email is required'),
  department: yup.string().required('Department is required'),
  salary: yup.number().positive('Salary must be positive').required('Salary is required'),
  joinDate: yup.string().required('Join date is required'),
  dummy: yup.array().of(
    yup.object().shape({
      name: yup.string().required('Name is required'),
      email: yup.string().email('Invalid email').required('Email is required'),
      department: yup.string().required('Department is required'),
      salary: yup.number().positive('Salary must be positive').required('Salary is required'),
      joinDate: yup.string().required('Join date is required'),
    })
  ).default([]),
});

type FormData = Omit<Employee, 'id' | 'attendance'> & {
  dummy: {
    name: string;
    email: string;
    department: string;
    salary: number;
    joinDate: string;
  }[];
};

const EmployeeList: React.FC = () => {
  const { employees, add, update, remove, removeMultiple } = useEmployees();
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [selected, setSelected] = useState<number[]>([]);
  const [expandedRow, setExpandedRow] = useState<number | null>(null); // For viewing details
  const {
    register,
    handleSubmit,
    reset,
    control,
    setValue,
    formState: { errors },
  } = useForm<FormData>({
    resolver: yupResolver(schema),
    defaultValues: { dummy: [] },
  });
  const { fields, append, remove: removeField } = useFieldArray({ control, name: 'dummy' });

  // Handle edit button click
  const handleEdit = (emp: Employee) => {
    setEditId(emp.id);
    setValue('name', emp.name);
    setValue('email', emp.email);
    setValue('department', emp.department);
    setValue('salary', emp.salary);
    setValue('joinDate', emp.joinDate);
    setOpen(true);
  };

  // Handle form submission
  const onSubmit = (data: FormData) => {
    if (editId) {
      // Edit mode: Update single employee
      update(editId, {
        name: data.name,
        email: data.email,
        department: data.department,
        salary: data.salary,
        joinDate: data.joinDate,
      });
    } else {
      // Add mode: Add single employee and any multiple employees from dummy array
      if (data.name && data.email && data.department && data.salary && data.joinDate) {
        add({
          name: data.name,
          email: data.email,
          department: data.department,
          salary: data.salary,
          joinDate: data.joinDate,
          attendance: [],
        });
      }
      if (data.dummy && data.dummy.length > 0) {
        data.dummy.forEach((emp) => {
          add({
            name: emp.name,
            email: emp.email,
            department: emp.department,
            salary: emp.salary,
            joinDate: emp.joinDate,
            attendance: [],
          });
        });
      }
    }
    setOpen(false);
    reset({ name: '', email: '', department: '', salary: 0, joinDate: '', dummy: [] });
    setEditId(null);
  };

  // Handle delete single employee
  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to delete this employee?')) {
      remove(id);
    }
  };

  // Handle delete multiple employees
  const handleMultipleDelete = () => {
    if (selected.length > 0 && window.confirm(`Delete ${selected.length} employees?`)) {
      removeMultiple(selected);
      setSelected([]);
    }
  };

  // Handle row selection for bulk delete
  const handleSelect = (id: number) => {
    setSelected((prev) => (prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]));
  };

  // Handle adding multiple employee fields
  const handleAddMultiple = () => {
    append({ name: '', email: '', department: '', salary: 0, joinDate: '' });
    setOpen(true);
  };

  // Handle row expansion for details
  const handleExpand = (id: number) => {
    setExpandedRow(expandedRow === id ? null : id);
  };

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h5" gutterBottom>Employees</Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Select</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Department</TableCell>
              <TableCell>Salary</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {employees.map((emp) => (
              <React.Fragment key={emp.id}>
                <TableRow>
                  <TableCell>
                    <Checkbox checked={selected.includes(emp.id)} onChange={() => handleSelect(emp.id)} />
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      {emp.name}
                      <IconButton size="small" onClick={() => handleExpand(emp.id)}>
                        {expandedRow === emp.id ? <ExpandLess /> : <ExpandMore />}
                      </IconButton>
                    </Box>
                  </TableCell>
                  <TableCell>{emp.email}</TableCell>
                  <TableCell>{emp.department}</TableCell>
                  <TableCell>${emp.salary}</TableCell>
                  <TableCell>
                    <IconButton onClick={() => handleEdit(emp)}>
                      <Edit />
                    </IconButton>
                    <IconButton onClick={() => handleDelete(emp.id)} color="error">
                      <Delete />
                    </IconButton>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell colSpan={6} style={{ paddingBottom: 0, paddingTop: 0 }}>
                    <Collapse in={expandedRow === emp.id} timeout="auto" unmountOnExit>
                      <Box sx={{ p: 2, bgcolor: '#f5f5f5' }}>
                        <Typography variant="subtitle1">Details</Typography>
                        <Typography>ID: {emp.id}</Typography>
                        <Typography>Join Date: {emp.joinDate}</Typography>
                        <Typography>Attendance: {emp.attendance.length > 0 ? emp.attendance.join(', ') : 'No records'}</Typography>
                      </Box>
                    </Collapse>
                  </TableCell>
                </TableRow>
              </React.Fragment>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Box sx={{ mt: 2, display: 'flex', gap: 1 }}>
        <Button onClick={() => { setOpen(true); setEditId(null); reset({ dummy: [] }); }} startIcon={<Add />} variant="contained">
          Add Employee
        </Button>
        {selected.length > 0 && (
          <Button onClick={handleMultipleDelete} color="error" variant="outlined">
            Delete Selected ({selected.length})
          </Button>
        )}
        <Button onClick={handleAddMultiple} startIcon={<Add />} variant="outlined">
          Add Multiple
        </Button>
      </Box>

      {/* Dialog for Add/Edit/Multiple Add */}
      <Dialog open={open} onClose={() => { setOpen(false); reset({ dummy: [] }); setEditId(null); }} maxWidth="sm" fullWidth>
        <DialogTitle>{editId ? 'Edit Employee' : fields.length > 0 ? 'Add Multiple Employees' : 'Add Employee'}</DialogTitle>
        <DialogContent>
          <form onSubmit={handleSubmit(onSubmit)}>
            {editId || fields.length === 0 ? (
              <>
                <TextField
                  {...register('name')}
                  label="Name"
                  fullWidth
                  margin="normal"
                  error={!!errors.name}
                  helperText={errors.name?.message}
                />
                <TextField
                  {...register('email')}
                  label="Email"
                  fullWidth
                  margin="normal"
                  error={!!errors.email}
                  helperText={errors.email?.message}
                />
                <TextField
                  {...register('department')}
                  label="Department"
                  fullWidth
                  margin="normal"
                  error={!!errors.department}
                  helperText={errors.department?.message}
                />
                <TextField
                  {...register('salary')}
                  label="Salary"
                  type="number"
                  fullWidth
                  margin="normal"
                  error={!!errors.salary}
                  helperText={errors.salary?.message}
                />
                <TextField
                  {...register('joinDate')}
                  label="Join Date"
                  type="date"
                  fullWidth
                  margin="normal"
                  InputLabelProps={{ shrink: true }}
                  error={!!errors.joinDate}
                  helperText={errors.joinDate?.message}
                />
              </>
            ) : (
              fields.map((field, idx) => (
                <Box key={field.id} sx={{ border: '1px solid #eee', p: 2, mb: 2 }}>
                  <Typography variant="subtitle2">Employee {idx + 1}</Typography>
                  <TextField
                    {...register(`dummy.${idx}.name`)}
                    label="Name"
                    fullWidth
                    margin="normal"
                    error={!!errors.dummy?.[idx]?.name}
                    helperText={errors.dummy?.[idx]?.name?.message}
                  />
                  <TextField
                    {...register(`dummy.${idx}.email`)}
                    label="Email"
                    fullWidth
                    margin="normal"
                    error={!!errors.dummy?.[idx]?.email}
                    helperText={errors.dummy?.[idx]?.email?.message}
                  />
                  <TextField
                    {...register(`dummy.${idx}.department`)}
                    label="Department"
                    fullWidth
                    margin="normal"
                    error={!!errors.dummy?.[idx]?.department}
                    helperText={errors.dummy?.[idx]?.department?.message}
                  />
                  <TextField
                    {...register(`dummy.${idx}.salary`)}
                    label="Salary"
                    type="number"
                    fullWidth
                    margin="normal"
                    error={!!errors.dummy?.[idx]?.salary}
                    helperText={errors.dummy?.[idx]?.salary?.message}
                  />
                  <TextField
                    {...register(`dummy.${idx}.joinDate`)}
                    label="Join Date"
                    type="date"
                    fullWidth
                    margin="normal"
                    InputLabelProps={{ shrink: true }}
                    error={!!errors.dummy?.[idx]?.joinDate}
                    helperText={errors.dummy?.[idx]?.joinDate?.message}
                  />
                  <Button onClick={() => removeField(idx)} startIcon={<Delete />} color="error" sx={{ mt: 1 }}>
                    Remove
                  </Button>
                </Box>
              ))
            )}
            {fields.length > 0 && (
              <Button
                onClick={() => append({ name: '', email: '', department: '', salary: 0, joinDate: '' })}
                startIcon={<Add />}
                sx={{ mb: 2 }}
              >
                Add Another Employee
              </Button>
            )}
            <DialogActions>
              <Button
                onClick={() => {
                  setOpen(false);
                  reset({ dummy: [] });
                  setEditId(null);
                }}
                startIcon={<Close />}
              >
                Cancel
              </Button>
              <Button type="submit" variant="contained">
                Save
              </Button>
            </DialogActions>
          </form>
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default EmployeeList;