// src/components/Report.tsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useEmployees } from '../contexts/EmployeeContext';
import { generatePDF, generateExcel, ReportType } from '../utils/reportUtils';
import { getAttendanceReport, getHiringTrends, getDepartmentGrowth } from '../utils/mockData';
import Grid from '@mui/material/Grid';
import {
  Box,
  Button,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Alert,
  AppBar,
  Toolbar,
  IconButton,
} from '@mui/material';
import { ArrowBack } from '@mui/icons-material';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  ResponsiveContainer,
} from 'recharts';

const Report: React.FC = () => {
  const { employees } = useEmployees();
  const navigate = useNavigate();
  const [message, setMessage] = useState<string | null>(null);

  const showMessage = (msg: string) => {
    setMessage(msg);
    setTimeout(() => setMessage(null), 3000);
  };

  const handleGeneratePDF = (type: ReportType) => {
    try {
      const success = generatePDF(employees, type);
      if (success) {
        showMessage(`✅ Successfully generated ${type} PDF report.`);
      } else {
        showMessage(`⚠️ No data available for ${type} PDF report.`);
      }
    } catch (error) {
      console.error('PDF generation error:', error);
      showMessage('❌ Failed to generate PDF report.');
    }
  };

  const handleGenerateExcel = (type: ReportType) => {
    try {
      const success = generateExcel(employees, type);
      if (success) {
        showMessage(`✅ Successfully generated ${type} Excel report.`);
      } else {
        showMessage(`⚠️ No data available for ${type} Excel report.`);
      }
    } catch (error) {
      console.error('Excel generation error:', error);
      showMessage('❌ Failed to generate Excel report.');
    }
  };

  const hiringTrends = getHiringTrends();
  const departmentGrowth = getDepartmentGrowth();
  const attendanceData = getAttendanceReport();

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <IconButton onClick={() => navigate('/dashboard')} color="inherit" edge="start">
            <ArrowBack />
          </IconButton>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Reports
          </Typography>
        </Toolbar>
      </AppBar>
      
      <Box sx={{ p: 3, maxWidth: '1200px', mx: 'auto' }}>
        {message && (
          <Alert
            onClose={() => setMessage(null)}
            severity={message.includes('Failed') ? 'error' : message.includes('No data') ? 'warning' : 'success'}
            sx={{ mb: 2 }}
          >
            {message}
          </Alert>
        )}
        
        <Typography variant="h5" gutterBottom>
          Generate Reports
        </Typography>

        {/* Report Generation Section */}
        <Box sx={{ mb: 4 }}>
          <Grid container spacing={2}>
            {[
              { type: ReportType.Directory, label: 'Directory' },
              { type: ReportType.Attendance, label: 'Attendance' },
              { type: ReportType.Salary, label: 'Salary' },
              { type: ReportType.Performance, label: 'Performance' },
            ].map(({ type, label }) => (
              <Grid item xs={12} sm={6} md={3} key={type}>
                <Paper sx={{ p: 2, height: '100%', display: 'flex', flexDirection: 'column' }}>
                  <Typography variant="subtitle1" gutterBottom align="center">
                    {label} Report
                  </Typography>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, flex: 1, justifyContent: 'center' }}>
                    <Button
                      onClick={() => handleGeneratePDF(type)}
                      variant="contained"
                      size="small"
                      fullWidth
                    >
                      PDF
                    </Button>
                    <Button 
                      onClick={() => handleGenerateExcel(type)} 
                      variant="outlined" 
                      size="small"
                      fullWidth
                    >
                      Excel
                    </Button>
                  </Box>
                </Paper>
              </Grid>
            ))}
          </Grid>
        </Box>

        {/* Charts and Analytics Section */}
        <Box>
          {/* Hiring Trend Analysis */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Hiring Trend Analysis
            </Typography>
            {hiringTrends.length > 0 ? (
              <Box sx={{ width: '100%', height: 300, mt: 2 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={hiringTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="hires" stroke="#1976d2" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </Box>
            ) : (
              <Alert severity="warning" sx={{ mt: 2 }}>No hiring trend data available.</Alert>
            )}
          </Paper>

          {/* Department Growth */}
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Department Growth
            </Typography>
            {departmentGrowth.length > 0 ? (
              <Box sx={{ width: '100%', height: 300, mt: 2 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={departmentGrowth}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="dept" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="count" fill="#1976d2" />
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            ) : (
              <Alert severity="warning" sx={{ mt: 2 }}>No department growth data available.</Alert>
            )}
          </Paper>

          {/* Attendance Patterns */}
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Attendance Patterns
            </Typography>
            {attendanceData.length > 0 ? (
              <TableContainer sx={{ mt: 2, maxHeight: 400 }}>
                <Table stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 'bold' }}>Employee Name</TableCell>
                      <TableCell sx={{ fontWeight: 'bold' }}>Days Attended</TableCell>
                      <TableCell sx={{ fontWeight: 'bold' }}>Attendance Rate</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {attendanceData.map((data) => (
                      <TableRow key={data.name} hover>
                        <TableCell>{data.name}</TableCell>
                        <TableCell>{data.days}</TableCell>
                        <TableCell>
                          <Box
                            component="span"
                            sx={{
                              px: 1,
                              py: 0.5,
                              borderRadius: 1,
                              backgroundColor: data.days >= 20 ? '#4caf50' : 
                                             data.days >= 15 ? '#ff9800' : '#f44336',
                              color: 'white',
                              fontSize: '0.875rem'
                            }}
                          >
                            {Math.round((data.days / 22) * 100)}%
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            ) : (
              <Alert severity="warning" sx={{ mt: 2 }}>No attendance data available.</Alert>
            )}
          </Paper>
        </Box>
      </Box>
    </>
  );
};

export default Report;
