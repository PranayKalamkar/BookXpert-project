// src/utils/mockData.ts
import { Employee } from '../types/employee';

let employees: Employee[] = [
  {
    id: 1,
    name: 'John Doe',
    email: 'john@example.com',
    department: 'Engineering',
    salary: 75000,
    joinDate: '2025-01-15',
    attendance: ['2025-09-01', '2025-09-02']
  },
  {
    id: 2,
    name: 'Jane Smith',
    email: 'jane@example.com',
    department: 'HR',
    salary: 65000,
    joinDate: '2025-03-10',
    attendance: ['2025-09-01']
  },
  // Add more mock data as needed
];

// Save to localStorage (simulate DB save)
export const saveEmployees = (data: Employee[]) => {
  localStorage.setItem('employees', JSON.stringify(data));
  employees = data;
};

// Load from localStorage (simulate API fetch)
export const loadEmployees = (): Employee[] => {
  const saved = localStorage.getItem('employees');
  if (saved) {
    employees = JSON.parse(saved);
  }
  return employees;
};

// Simulate API calls (CRUD)
export const getEmployees = () => loadEmployees();

export const addEmployee = (employee: Omit<Employee, 'id'>) => {
  const id = Date.now(); // Simple ID gen
  const newEmp: Employee = { ...employee, id, attendance: [] };
  employees.push(newEmp);
  saveEmployees(employees);
  return newEmp;
};

export const updateEmployee = (id: number, updates: Partial<Employee>) => {
  const index = employees.findIndex(e => e.id === id);
  if (index !== -1) {
    employees[index] = { ...employees[index], ...updates };
    saveEmployees(employees);
    return employees[index];
  }
  return null;
};

export const deleteEmployee = (id: number) => {
  employees = employees.filter(e => e.id !== id);
  saveEmployees(employees);
};

export const deleteMultiple = (ids: number[]) => {
  employees = employees.filter(e => !ids.includes(e.id));
  saveEmployees(employees);
};

// Mock attendance/salary data for reports
export const getAttendanceReport = () => employees.map(e => ({ name: e.name, days: e.attendance.length }));
export const getSalaryReport = () => employees.filter(e => e.department === 'Engineering').map(e => ({ name: e.name, salary: e.salary }));
// Bonus mocks
export const getHiringTrends = () => [{ month: 'Jan 2025', hires: 5 }, { month: 'Feb 2025', hires: 3 }];
export const getDepartmentGrowth = () => [{ dept: 'Engineering', count: 10 }, { dept: 'HR', count: 5 }];