// src/utils/reportUtils.ts
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Employee } from '../types/employee';
import { getAttendanceReport, getSalaryReport } from './mockData';

// Extend jsPDF type to include autoTable
declare module 'jspdf' {
  interface jsPDF {
    autoTable: (...args: any[]) => void;
  }
}

export enum ReportType {
  Directory = 'directory',
  Attendance = 'attendance',
  Salary = 'salary',
  Performance = 'performance',
}

/**
 * Generate PDF reports
 */
export const generatePDF = (employees: Employee[], type: ReportType): boolean => {
  const doc = new jsPDF();
  doc.text('Employee Management Report', 14, 20);
  let startY = 30;

  if (type === ReportType.Directory) {
    if (!employees.length) return false;
    doc.autoTable({
      startY,
      head: [['ID', 'Name', 'Email', 'Department']],
      body: employees.map((e) => [e.id, e.name, e.email, e.department]),
    });
  } else if (type === ReportType.Attendance) {
    const data = getAttendanceReport();
    if (!data.length) return false;
    doc.autoTable({
      startY,
      head: [['Name', 'Days Attended']],
      body: data.map((d) => [d.name, d.days]),
    });
  } else if (type === ReportType.Salary) {
    const data = getSalaryReport();
    if (!data.length) return false;
    doc.autoTable({
      startY,
      head: [['Name', 'Salary']],
      body: data.map((d) => [d.name, `$${d.salary}`]),
    });
  } else if (type === ReportType.Performance) {
    const data = getAttendanceReport();
    if (!data.length) return false;
    doc.text('Performance Metrics', 14, startY);
    startY += 10;
    doc.autoTable({
      startY,
      head: [['Name', 'Attendance %']],
      body: data.map((d) => [d.name, `${Math.round((d.days / 22) * 100)}%`]),
    });
  }

  doc.save(`${type}-report.pdf`);
  return true;
};

/**
 * Generate Excel reports
 */
export const generateExcel = (employees: Employee[], type: ReportType): boolean => {
  let data: any[] = [];

  if (type === ReportType.Directory) {
    if (!employees.length) return false;
    data = employees.map((e) => ({
      ID: e.id,
      Name: e.name,
      Email: e.email,
      Department: e.department,
      Salary: e.salary,
      JoinDate: e.joinDate,
    }));
  } else if (type === ReportType.Attendance) {
    const attendance = getAttendanceReport();
    if (!attendance.length) return false;
    data = attendance.map((d) => ({
      Name: d.name,
      DaysAttended: d.days,
      AttendancePercent: `${Math.round((d.days / 22) * 100)}%`,
    }));
  } else if (type === ReportType.Salary) {
    const salaryData = getSalaryReport();
    if (!salaryData.length) return false;
    data = salaryData.map((d) => ({
      Name: d.name,
      Salary: d.salary,
    }));
  } else if (type === ReportType.Performance) {
    const perfData = getAttendanceReport();
    if (!perfData.length) return false;
    data = perfData.map((d) => ({
      Name: d.name,
      AttendancePercent: `${Math.round((d.days / 22) * 100)}%`,
    }));
  }

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, ws, type);
  const buf = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
  saveAs(new Blob([buf]), `${type}-report.xlsx`);
  return true;
};
