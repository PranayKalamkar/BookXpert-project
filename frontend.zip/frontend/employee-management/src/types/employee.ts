// src/types/employee.ts
export interface Employee {
  id: number;
  name: string;
  email: string;
  department: string;
  salary: number;
  joinDate: string; // ISO date, e.g., "2025-01-01"
  attendance: string[]; // Array of dates like ["2025-09-01"]
}

export interface AuthUser {
  username: string;
  token: string; // Mock token
}