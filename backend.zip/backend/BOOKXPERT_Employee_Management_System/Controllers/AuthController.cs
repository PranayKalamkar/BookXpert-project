﻿using BOOKXPERT_Employee_Management_System.Models;
using BOOKXPERT_Employee_Management_System.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace BOOKXPERT_Employee_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthRepository _authService;
        private readonly ILogger<AuthController> _logger;

        public AuthController(IAuthRepository authService, ILogger<AuthController> logger)
        {
            _authService = authService;
            _logger = logger;
        }

        [HttpPost("login")]
        public async Task<ActionResult<AuthResponse>> Login(LoginModel request)
        {
            try
            {
                var token = await _authService.Login(request.Username, request.Password);

                if (string.IsNullOrEmpty(token))
                {
                    return Unauthorized(new { message = "Invalid username or password" });
                }

                return Ok(new AuthResponse { Token = token, Username = request.Username });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during login");
                return StatusCode(500, new { message = "Internal server error during login" });
            }
        }

        [HttpPost("register")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> Register(RegisterModel request)
        {
            try
            {
                var user = new Models.UserModel
                {
                    Username = request.Username,
                    Email = request.Email,
                    Role = request.Role
                };

                var result = await _authService.Register(user, request.Password);

                if (!result)
                {
                    return BadRequest(new { message = "Username or email already exists" });
                }

                return Ok(new { message = "User registered successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during user registration");
                return StatusCode(500, new { message = "Internal server error during registration" });
            }
        }

        [HttpGet("me")]
        [Authorize]
        public async Task<ActionResult<UserModel>> GetCurrentUser()
        {
            try
            {
                var username = User.Identity.Name;
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var role = User.FindFirst(ClaimTypes.Role)?.Value;

                return Ok(new UserModel
                {
                    Id = int.Parse(userId),
                    Username = username,
                    Role = role
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting current user");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
    }
}
