﻿using BOOKXPERT_Employee_Management_System.Models;
using BOOKXPERT_Employee_Management_System.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BOOKXPERT_Employee_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AttendanceController : ControllerBase
    {
        private readonly IAttendanceRepository _attendanceRepository;
        private readonly IEmployeeRepository _employeeRepository;
        private readonly ILogger<AttendanceController> _logger;

        public AttendanceController(
            IAttendanceRepository attendanceRepository,
            IEmployeeRepository employeeRepository,
            ILogger<AttendanceController> logger)
        {
            _attendanceRepository = attendanceRepository;
            _employeeRepository = employeeRepository;
            _logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<AttendanceDto>>> GetAttendances(
            [FromQuery] DateTime? startDate,
            [FromQuery] DateTime? endDate,
            [FromQuery] int? employeeId)
        {
            try
            {
                var attendances = await _attendanceRepository.GetAttendancesAsync(startDate, endDate, employeeId);
                var attendanceDtos = attendances.Select(a => MapToDto(a));
                return Ok(attendanceDtos);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting attendances");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<AttendanceDto>> GetAttendance(int id)
        {
            try
            {
                var attendance = await _attendanceRepository.GetAttendanceByIdAsync(id);

                if (attendance == null)
                {
                    return NotFound();
                }

                return MapToDto(attendance);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting attendance with ID {id}");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        [HttpPost]
        public async Task<ActionResult<AttendanceDto>> PostAttendance(AttendanceCreateDto attendanceDto)
        {
            try
            {
                // Check if employee exists
                var employee = await _employeeRepository.GetEmployeeByIdAsync(attendanceDto.EmployeeId);
                if (employee == null)
                {
                    return BadRequest(new { message = "Employee not found" });
                }

                var attendance = new AttendanceModel
                {
                    EmployeeId = attendanceDto.EmployeeId,
                    Date = attendanceDto.Date,
                    TimeIn = attendanceDto.TimeIn,
                    TimeOut = attendanceDto.TimeOut,
                    HoursWorked = attendanceDto.HoursWorked,
                    Status = attendanceDto.Status
                };

                var attendanceId = await _attendanceRepository.AddAttendanceAsync(attendance);

                if (attendanceId > 0)
                {
                    attendance.Id = attendanceId;
                    return CreatedAtAction(nameof(GetAttendance), new { id = attendanceId }, MapToDto(attendance));
                }

                return BadRequest(new { message = "Unable to create attendance record" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating attendance");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutAttendance(int id, AttendanceUpdateDto attendanceDto)
        {
            try
            {
                if (id != attendanceDto.Id)
                {
                    return BadRequest();
                }

                var existingAttendance = await _attendanceRepository.GetAttendanceByIdAsync(id);
                if (existingAttendance == null)
                {
                    return NotFound();
                }

                var attendance = new AttendanceModel
                {
                    Id = attendanceDto.Id,
                    EmployeeId = attendanceDto.EmployeeId,
                    Date = attendanceDto.Date,
                    TimeIn = attendanceDto.TimeIn,
                    TimeOut = attendanceDto.TimeOut,
                    HoursWorked = attendanceDto.HoursWorked,
                    Status = attendanceDto.Status
                };

                var result = await _attendanceRepository.UpdateAttendanceAsync(attendance);

                if (result)
                {
                    return NoContent();
                }

                return BadRequest(new { message = "Unable to update attendance record" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating attendance with ID {id}");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAttendance(int id)
        {
            try
            {
                var attendance = await _attendanceRepository.GetAttendanceByIdAsync(id);
                if (attendance == null)
                {
                    return NotFound();
                }

                var result = await _attendanceRepository.DeleteAttendanceAsync(id);

                if (result)
                {
                    return NoContent();
                }

                return BadRequest(new { message = "Unable to delete attendance record" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting attendance with ID {id}");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        [HttpPost("checkin")]
        public async Task<ActionResult<AttendanceDto>> CheckIn(CheckInRequest request)
        {
            try
            {
                var employee = await _employeeRepository.GetEmployeeByIdAsync(request.EmployeeId);
                if (employee == null)
                {
                    return BadRequest(new { message = "Employee not found" });
                }

                var today = DateTime.Today;
                var existingAttendance = await _attendanceRepository.GetAttendanceByDateAsync(request.EmployeeId, today);

                if (existingAttendance != null && existingAttendance.TimeIn.HasValue)
                {
                    return BadRequest(new { message = "Employee already checked in today" });
                }

                var attendance = new AttendanceModel
                {
                    EmployeeId = request.EmployeeId,
                    Date = today,
                    TimeIn = DateTime.Now,
                    Status = "Present"
                };

                var attendanceId = await _attendanceRepository.AddAttendanceAsync(attendance);

                if (attendanceId > 0)
                {
                    attendance.Id = attendanceId;
                    return CreatedAtAction(nameof(GetAttendance), new { id = attendanceId }, MapToDto(attendance));
                }

                return BadRequest(new { message = "Unable to check in" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during check in");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        [HttpPost("checkout")]
        public async Task<ActionResult<AttendanceDto>> CheckOut(CheckOutRequest request)
        {
            try
            {
                var today = DateTime.Today;
                var attendance = await _attendanceRepository.GetAttendanceByDateAsync(request.EmployeeId, today);

                if (attendance == null || !attendance.TimeIn.HasValue)
                {
                    return BadRequest(new { message = "Employee hasn't checked in today" });
                }

                if (attendance.TimeOut.HasValue)
                {
                    return BadRequest(new { message = "Employee already checked out today" });
                }

                var timeOut = DateTime.Now;
                attendance.TimeOut = timeOut;

                // Calculate hours worked
                if (attendance.TimeIn.HasValue)
                {
                    attendance.HoursWorked = (decimal)(timeOut - attendance.TimeIn.Value).TotalHours;
                }

                var result = await _attendanceRepository.UpdateAttendanceAsync(attendance);

                if (result)
                {
                    return Ok(MapToDto(attendance));
                }

                return BadRequest(new { message = "Unable to check out" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during check out");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        [HttpGet("employee/{employeeId}")]
        public async Task<ActionResult<IEnumerable<AttendanceDto>>> GetEmployeeAttendances(
            int employeeId,
            [FromQuery] DateTime? startDate,
            [FromQuery] DateTime? endDate)
        {
            try
            {
                var employee = await _employeeRepository.GetEmployeeByIdAsync(employeeId);
                if (employee == null)
                {
                    return NotFound(new { message = "Employee not found" });
                }

                var attendances = await _attendanceRepository.GetAttendancesByEmployeeAsync(employeeId, startDate, endDate);
                var attendanceDtos = attendances.Select(a => MapToDto(a));
                return Ok(attendanceDtos);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting attendances for employee {employeeId}");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        [HttpGet("summary")]
        public async Task<ActionResult<AttendanceSummaryDto>> GetAttendanceSummary(
            [FromQuery] DateTime startDate,
            [FromQuery] DateTime endDate,
            [FromQuery] int? employeeId)
        {
            try
            {
                var attendances = await _attendanceRepository.GetAttendancesAsync(startDate, endDate, employeeId);

                var summary = new AttendanceSummaryDto
                {
                    TotalRecords = (endDate - startDate).Days + 1,
                    PresentDays = attendances.Count(a => a.Status == "Present"),
                    AbsentDays = attendances.Count(a => a.Status == "Absent"),
                    LateDays = attendances.Count(a => a.Status == "Late"),
                    LeaveDays = attendances.Count(a => a.Status == "Leave"),
                    TotalHours = attendances.Sum(a => a.HoursWorked)
                };

                return Ok(summary);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting attendance summary");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        private AttendanceDto MapToDto(AttendanceModel attendance)
        {
            return new AttendanceDto
            {
                Id = attendance.Id,
                EmployeeId = attendance.EmployeeId,
                Date = attendance.Date,
                TimeIn = attendance.TimeIn,
                TimeOut = attendance.TimeOut,
                HoursWorked = attendance.HoursWorked,
                Status = attendance.Status
            };
        }

    }
}
