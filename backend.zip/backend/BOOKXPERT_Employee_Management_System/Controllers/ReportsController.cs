﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BOOKXPERT_Employee_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportsController : ControllerBase
    {
        private readonly IReportService _reportService;
        private readonly ILogger<ReportsController> _logger;

        public ReportsController(IReportService reportService, ILogger<ReportsController> logger)
        {
            _reportService = reportService;
            _logger = logger;
        }

        // Employee Directory Report
        [HttpGet("employee-directory")]
        public async Task<IActionResult> GenerateEmployeeDirectoryReport([FromQuery] string format = "pdf")
        {
            try
            {
                ValidateReportFormat(format);

                var reportBytes = await _reportService.GenerateEmployeeDirectoryReport(format);
                return CreateFileResponse(reportBytes, format, "EmployeeDirectory");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating employee directory report");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        // Department Report
        [HttpGet("department")]
        public async Task<IActionResult> GenerateDepartmentReport(
            [FromQuery] string department,
            [FromQuery] string format = "pdf")
        {
            try
            {
                ValidateReportFormat(format);

                if (string.IsNullOrEmpty(department))
                {
                    return BadRequest(new { message = "Department is required" });
                }

                var reportBytes = await _reportService.GenerateDepartmentReport(format, department);
                return CreateFileResponse(reportBytes, format, $"DepartmentReport_{department}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating department report");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        // Attendance Report
        [HttpGet("attendance")]
        public async Task<IActionResult> GenerateAttendanceReport(
            [FromQuery] DateTime startDate,
            [FromQuery] DateTime endDate,
            [FromQuery] int? employeeId = null,
            [FromQuery] string format = "pdf")
        {
            try
            {
                ValidateReportFormat(format);
                ValidateDateRange(startDate, endDate);

                var reportBytes = await _reportService.GenerateAttendanceReport(format, startDate, endDate, employeeId);
                var fileName = employeeId.HasValue ?
                    $"AttendanceReport_{startDate:yyyyMMdd}_{endDate:yyyyMMdd}_Employee_{employeeId}" :
                    $"AttendanceReport_{startDate:yyyyMMdd}_{endDate:yyyyMMdd}";

                return CreateFileResponse(reportBytes, format, fileName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating attendance report");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        // Salary Report
        [HttpGet("salary")]
        public async Task<IActionResult> GenerateSalaryReport(
            [FromQuery] string department = null,
            [FromQuery] string format = "pdf")
        {
            try
            {
                ValidateReportFormat(format);

                var reportBytes = await _reportService.GenerateSalaryReport(format, department);
                var fileName = string.IsNullOrEmpty(department) ?
                    "SalaryReport_All" :
                    $"SalaryReport_Department_{department}";

                return CreateFileResponse(reportBytes, format, fileName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating salary report");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        // Hiring Trends Report
        [HttpGet("hiring-trends")]
        public async Task<IActionResult> GenerateHiringTrendReport(
            [FromQuery] int months = 12,
            [FromQuery] string format = "pdf")
        {
            try
            {
                ValidateReportFormat(format);
                ValidateMonthsParameter(months);

                var reportBytes = await _reportService.GenerateHiringTrendReport(format, months);
                return CreateFileResponse(reportBytes, format, $"HiringTrendReport_{months}Months");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating hiring trend report");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        // Department Growth Report
        [HttpGet("department-growth")]
        public async Task<IActionResult> GenerateDepartmentGrowthReport([FromQuery] string format = "pdf")
        {
            try
            {
                ValidateReportFormat(format);

                var reportBytes = await _reportService.GenerateDepartmentGrowthReport(format);
                return CreateFileResponse(reportBytes, format, "DepartmentGrowthReport");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating department growth report");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        // Attendance Patterns Report
        [HttpGet("attendance-patterns")]
        public async Task<IActionResult> GenerateAttendancePatternReport(
            [FromQuery] int months = 6,
            [FromQuery] string format = "pdf")
        {
            try
            {
                ValidateReportFormat(format);
                ValidateMonthsParameter(months, 60);

                var reportBytes = await _reportService.GenerateAttendancePatternReport(format, months);
                return CreateFileResponse(reportBytes, format, $"AttendancePatternReport_{months}Months");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating attendance pattern report");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        // Performance Metrics Report
        [HttpGet("performance")]
        public async Task<IActionResult> GeneratePerformanceReport([FromQuery] string format = "pdf")
        {
            try
            {
                ValidateReportFormat(format);

                var reportBytes = await _reportService.GeneratePerformanceReport(format);
                return CreateFileResponse(reportBytes, format, "PerformanceReport");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating performance report");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        // Helper methods
        private void ValidateReportFormat(string format)
        {
            if (format.ToLower() != "pdf" && format.ToLower() != "excel")
            {
                throw new ArgumentException("Format must be 'pdf' or 'excel'");
            }
        }

        private void ValidateDateRange(DateTime startDate, DateTime endDate)
        {
            if (startDate > endDate)
            {
                throw new ArgumentException("Start date cannot be after end date");
            }

            if ((endDate - startDate).Days > 365)
            {
                throw new ArgumentException("Date range cannot exceed 1 year");
            }
        }

        private void ValidateMonthsParameter(int months, int maxMonths = 60)
        {
            if (months < 1 || months > maxMonths)
            {
                throw new ArgumentException($"Months must be between 1 and {maxMonths}");
            }
        }

        private FileContentResult CreateFileResponse(byte[] fileBytes, string format, string baseFileName)
        {
            var contentType = format.ToLower() == "pdf" ?
                "application/pdf" :
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

            var extension = format.ToLower() == "pdf" ? "pdf" : "xlsx";
            var fileName = $"{baseFileName}.{extension}";

            return File(fileBytes, contentType, fileName);
        }
    }
}
