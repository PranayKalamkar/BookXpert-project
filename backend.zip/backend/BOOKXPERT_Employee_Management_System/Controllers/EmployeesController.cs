﻿using AutoMapper;
using BOOKXPERT_Employee_Management_System.Models;
using BOOKXPERT_Employee_Management_System.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Crypto;

namespace BOOKXPERT_Employee_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IMapper _mapper;
        private readonly ILogger<EmployeesController> _logger;

        public EmployeesController(IEmployeeRepository employeeRepository, IMapper mapper, ILogger<EmployeesController> logger)
        {
            _employeeRepository = employeeRepository;
            _mapper = mapper;
            _logger = logger;
        }

        // GET: api/employees
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeModel>>> GetEmployees()
        {
            try
            {
                var employees = await _employeeRepository.GetAllEmployeesAsync();
                var employeeDtos = _mapper.Map<IEnumerable<EmployeeModel>>(employees);
                return Ok(employeeDtos);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // GET: api/employees/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EmployeeModel>> GetEmployee(int id)
        {
            try
            {
                var employee = await _employeeRepository.GetEmployeeByIdAsync(id);

                if (employee == null)
                {
                    return NotFound();
                }

                return _mapper.Map<EmployeeModel>(employee);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: api/employees
        [HttpPost]
        public async Task<ActionResult<EmployeeModel>> PostEmployee(EmployeeModel employeeDto)
        {
            try
            {
                var employee = _mapper.Map<EmployeeModel>(employeeDto);
                var employeeId = await _employeeRepository.AddEmployeeAsync(employee);

                if (employeeId > 0)
                {
                    employee.Id = employeeId;
                    var createdEmployee = _mapper.Map<EmployeeModel>(employee);
                    return CreatedAtAction(nameof(GetEmployee), new { id = employeeId }, createdEmployee);
                }

                return BadRequest("Unable to create employee");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // PUT: api/employees/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEmployee(int id, EmployeeModel employeeDto)
        {
            try
            {
                if (id != employeeDto.Id)
                {
                    return BadRequest();
                }

                var existingEmployee = await _employeeRepository.GetEmployeeByIdAsync(id);
                if (existingEmployee == null)
                {
                    return NotFound();
                }

                var employee = _mapper.Map<EmployeeModel>(employeeDto);
                var result = await _employeeRepository.UpdateEmployeeAsync(employee);

                if (result)
                {
                    return NoContent();
                }

                return BadRequest("Unable to update employee");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // DELETE: api/employees/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            try
            {
                var employee = await _employeeRepository.GetEmployeeByIdAsync(id);
                if (employee == null)
                {
                    return NotFound();
                }

                var result = await _employeeRepository.DeleteEmployeeAsync(id);

                if (result)
                {
                    return NoContent();
                }

                return BadRequest("Unable to delete employee");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // GET: api/employees/search?term=john
        [HttpGet("search")]
        public async Task<ActionResult<IEnumerable<EmployeeModel>>> SearchEmployees([FromQuery] string term)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(term))
                {
                    return BadRequest("Search term is required");
                }

                var employees = await _employeeRepository.SearchEmployeesAsync(term);
                var employeeDtos = _mapper.Map<IEnumerable<EmployeeModel>>(employees);
                return Ok(employeeDtos);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // GET: api/employees/department/sales
        [HttpGet("department/{department}")]
        public async Task<ActionResult<IEnumerable<EmployeeModel>>> GetEmployeesByDepartment(string department)
        {
            try
            {
                var employees = await _employeeRepository.GetEmployeesByDepartmentAsync(department);
                var employeeDtos = _mapper.Map<IEnumerable<EmployeeModel>>(employees);
                return Ok(employeeDtos);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
