﻿using MySql.Data.MySqlClient;

namespace BOOKXPERT_Employee_Management_System.Data
{
    public interface IDatabaseConnection
    {
        MySqlConnection GetConnection();
    }

    public class DatabaseConnection : IDatabaseConnection
    {
        private readonly string _connectionString;

        public DatabaseConnection(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public MySqlConnection GetConnection()
        {
            return new MySqlConnection(_connectionString);
        }
    }
}
