﻿using BOOKXPERT_Employee_Management_System.Data;
using BOOKXPERT_Employee_Management_System.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.Common;

namespace BOOKXPERT_Employee_Management_System.Repositories
{
    public interface IEmployeeRepository
    {
        Task<IEnumerable<EmployeeModel>> GetAllEmployeesAsync();
        Task<EmployeeModel> GetEmployeeByIdAsync(int id);
        Task<int> AddEmployeeAsync(EmployeeModel employee);
        Task<bool> UpdateEmployeeAsync(EmployeeModel employee);
        Task<bool> DeleteEmployeeAsync(int id);
        Task<IEnumerable<EmployeeModel>> GetEmployeesByDepartmentAsync(string department);
        Task<IEnumerable<EmployeeModel>> SearchEmployeesAsync(string searchTerm);
    }


    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly IDatabaseConnection _databaseConnection;
        private readonly ILogger<EmployeeRepository> _logger;

        public EmployeeRepository(IDatabaseConnection databaseConnection, ILogger<EmployeeRepository> logger)
        {
            _databaseConnection = databaseConnection;
            _logger = logger;
        }

        public async Task<(IEnumerable<EmployeeModel> Employees, int TotalCount)> GetEmployeesAsync(EmployeeQueryParameters queryParams)
        {
            var employees = new List<EmployeeModel>();
            int totalCount = 0;

            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_GetEmployees", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@p_page_number", queryParams.PageNumber);
                        command.Parameters.AddWithValue("@p_page_size", queryParams.PageSize);
                        command.Parameters.AddWithValue("@p_department", string.IsNullOrEmpty(queryParams.Department) ? null : queryParams.Department);
                        command.Parameters.AddWithValue("@p_position", string.IsNullOrEmpty(queryParams.Position) ? null : queryParams.Position);
                        command.Parameters.AddWithValue("@p_sort_by", queryParams.SortBy);
                        command.Parameters.AddWithValue("@p_sort_order", queryParams.SortOrder);
                        command.Parameters.AddWithValue("@p_search_term", string.IsNullOrEmpty(queryParams.SearchTerm) ? null : queryParams.SearchTerm);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                employees.Add(MapEmployeeFromReader(reader));
                            }

                            if (await reader.NextResultAsync() && await reader.ReadAsync())
                            {
                                totalCount = reader.GetInt32("TotalCount");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting employees with query parameters");
                throw;
            }

            return (employees, totalCount);
        }

        public async Task<EmployeeModel?> GetEmployeeByIdAsync(int id)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                using (var command = new MySqlCommand("GetEmployeeById", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("empId", id);

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            return MapEmployeeFromReader(reader);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in GetEmployeeByIdAsync for Id {Id}", id);
                throw;
            }

            return null;
        }

        public async Task<int> AddEmployeeAsync(EmployeeModel employee)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                using (var command = new MySqlCommand("AddEmployee", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("FirstName", employee.FirstName);
                    command.Parameters.AddWithValue("LastName", employee.LastName);
                    command.Parameters.AddWithValue("Email", employee.Email);
                    command.Parameters.AddWithValue("DateOfBirth", employee.DateOfBirth);
                    command.Parameters.AddWithValue("HireDate", employee.HireDate);
                    command.Parameters.AddWithValue("Department", employee.Department);
                    command.Parameters.AddWithValue("Position", employee.Position);
                    command.Parameters.AddWithValue("Salary", employee.Salary);

                    var result = await command.ExecuteScalarAsync();
                    return Convert.ToInt32(result);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in AddEmployeeAsync for {@Employee}", employee);
                throw;
            }
        }

        public async Task<bool> UpdateEmployeeAsync(EmployeeModel employee)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                using (var command = new MySqlCommand("UpdateEmployee", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("Id", employee.Id);
                    command.Parameters.AddWithValue("FirstName", employee.FirstName);
                    command.Parameters.AddWithValue("LastName", employee.LastName);
                    command.Parameters.AddWithValue("Email", employee.Email);
                    command.Parameters.AddWithValue("DateOfBirth", employee.DateOfBirth);
                    command.Parameters.AddWithValue("HireDate", employee.HireDate);
                    command.Parameters.AddWithValue("Department", employee.Department);
                    command.Parameters.AddWithValue("Position", employee.Position);
                    command.Parameters.AddWithValue("Salary", employee.Salary);

                    var rowsAffected = await command.ExecuteNonQueryAsync();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in UpdateEmployeeAsync for Id {Id}", employee.Id);
                throw;
            }
        }

        public async Task<bool> DeleteEmployeeAsync(int id)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                using (var command = new MySqlCommand("DeleteEmployee", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("empId", id);

                    var rowsAffected = await command.ExecuteNonQueryAsync();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in DeleteEmployeeAsync for Id {Id}", id);
                throw;
            }
        }

        public async Task<IEnumerable<EmployeeModel>> GetEmployeesByDepartmentAsync(string department)
        {
            var employees = new List<EmployeeModel>();

            try
            {
                using (var connection = _databaseConnection.GetConnection())
                using (var command = new MySqlCommand("GetEmployeesByDepartment", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("dept", department);

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            employees.Add(MapEmployeeFromReader(reader));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in GetEmployeesByDepartmentAsync for department {Dept}", department);
                throw;
            }

            return employees;
        }

        public async Task<IEnumerable<EmployeeModel>> SearchEmployeesAsync(string searchTerm)
        {
            var employees = new List<EmployeeModel>();

            try
            {
                using (var connection = _databaseConnection.GetConnection())
                using (var command = new MySqlCommand("SearchEmployees", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("term", searchTerm);

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        var mysqlReader = reader as MySqlDataReader;
                        if (mysqlReader == null)
                            throw new InvalidCastException("Reader is not a MySqlDataReader.");

                        while (await mysqlReader.ReadAsync())
                        {
                            employees.Add(MapEmployeeFromReader(mysqlReader));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in SearchEmployeesAsync with search term {Term}", searchTerm);
                throw;
            }

            return employees;
        }
   
        private EmployeeModel MapEmployeeFromReader(DbDataReader reader)
        {
            return new EmployeeModel
            {
                Id = reader.GetInt32("Id"),
                FirstName = reader.GetString("FirstName"),
                LastName = reader.GetString("LastName"),
                Email = reader.GetString("Email"),
                DateOfBirth = reader.GetDateTime("DateOfBirth"),
                HireDate = reader.GetDateTime("HireDate"),
                Department = reader.GetString("Department"),
                Position = reader.GetString("Position"),
                Salary = reader.GetDouble("Salary"),
                CreatedAt = reader.GetDateTime("CreatedAt"),
                UpdatedAt = reader.IsDBNull("UpdatedAt") ? null : reader.GetDateTime("UpdatedAt")
            };
        }

    }
}
