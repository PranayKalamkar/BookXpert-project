﻿using BOOKXPERT_Employee_Management_System.Data;
using BOOKXPERT_Employee_Management_System.Models;
using BOOKXPERT_Employee_Management_System.Services;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Crypto.Generators;
using System.Data;
using System.Security.Claims;
using System.Text;

namespace BOOKXPERT_Employee_Management_System.Repositories
{
    public interface IAuthRepository
    {
        Task<string> Login(string username, string password);
        Task<bool> Register(UserModel user, string password);
    }

    public class AuthRepository : IAuthRepository
    {
        private readonly IDatabaseConnection _databaseConnection;
        private readonly IConfiguration _configuration;

        public AuthRepository(IDatabaseConnection databaseConnection, IConfiguration configuration)
        {
            _databaseConnection = databaseConnection;
            _configuration = configuration;
        }

        public async Task<string> Login(string username, string password)
        {
            using (var connection = _databaseConnection.GetConnection())
            using (var command = new MySqlCommand("LoginUser", connection))
            {
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("p_username", username);

                using (var reader = await command.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        var storedHash = reader.GetString("PasswordHash");
                        if (BCrypt.Net.BCrypt.Verify(password, storedHash))
                        {
                            var user = new UserModel
                            {
                                Id = reader.GetInt32("Id"),
                                Username = reader.GetString("Username"),
                                Email = reader.GetString("Email"),
                                Role = reader.GetString("Role")
                            };

                            return JwtToken.GenerateJwtToken(user, _configuration);
                        }
                    }
                }
            }

            return null;
        }

        public async Task<bool> Register(UserModel user, string password)
        {
            using (var connection = _databaseConnection.GetConnection())
            {
                // Check if user already exists
                using (var checkCommand = new MySqlCommand("CheckUserExists", connection))
                {
                    checkCommand.CommandType = CommandType.StoredProcedure;
                    checkCommand.Parameters.AddWithValue("p_username", user.Username);
                    checkCommand.Parameters.AddWithValue("p_email", user.Email);

                    var count = Convert.ToInt32(await checkCommand.ExecuteScalarAsync());
                    if (count > 0)
                        return false;
                }

                // Insert new user
                using (var insertCommand = new MySqlCommand("RegisterUser", connection))
                {
                    insertCommand.CommandType = CommandType.StoredProcedure;
                    insertCommand.Parameters.AddWithValue("p_username", user.Username);
                    insertCommand.Parameters.AddWithValue("p_email", user.Email);
                    insertCommand.Parameters.AddWithValue("p_passwordHash", BCrypt.Net.BCrypt.HashPassword(password));
                    insertCommand.Parameters.AddWithValue("p_role", user.Role);
                    insertCommand.Parameters.AddWithValue("p_createdAt", DateTime.UtcNow);

                    var rowsAffected = await insertCommand.ExecuteNonQueryAsync();
                    return rowsAffected > 0;
                }
            }
        }

        
    }
}
