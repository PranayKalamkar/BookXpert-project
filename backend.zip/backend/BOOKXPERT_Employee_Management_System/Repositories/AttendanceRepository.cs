﻿using BOOKXPERT_Employee_Management_System.Data;
using BOOKXPERT_Employee_Management_System.Models;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.Common;

namespace BOOKXPERT_Employee_Management_System.Repositories
{

    public interface IAttendanceRepository
    {
        Task<IEnumerable<AttendanceModel>> GetAttendancesAsync(DateTime? startDate, DateTime? endDate, int? employeeId);
        Task<AttendanceModel> GetAttendanceByIdAsync(int id);
        Task<AttendanceModel> GetAttendanceByDateAsync(int employeeId, DateTime date);
        Task<IEnumerable<AttendanceModel>> GetAttendancesByEmployeeAsync(int employeeId, DateTime? startDate, DateTime? endDate);
        Task<int> AddAttendanceAsync(AttendanceModel attendance);
        Task<bool> UpdateAttendanceAsync(AttendanceModel attendance);
        Task<bool> DeleteAttendanceAsync(int id);

        // Additional methods for business logic
        Task<AttendanceSummaryDto> GetAttendanceSummaryAsync(int employeeId, DateTime startDate, DateTime endDate);
        Task<IEnumerable<MonthlyAttendanceTrend>> GetMonthlyAttendanceTrendsAsync(int employeeId, int months);
        Task<bool> CanCheckInAsync(int employeeId, DateTime date);
        Task<bool> CanCheckOutAsync(int employeeId, DateTime date);
    }

    public class AttendanceRepository : IAttendanceRepository
    {
        private readonly IDatabaseConnection _databaseConnection;
        private readonly ILogger<AttendanceRepository> _logger;

        public AttendanceRepository(IDatabaseConnection databaseConnection, ILogger<AttendanceRepository> logger)
        {
            _databaseConnection = databaseConnection;
            _logger = logger;
        }

        public async Task<IEnumerable<AttendanceModel>> GetAttendancesAsync(DateTime? startDate, DateTime? endDate, int? employeeId)
        {
            var attendances = new List<AttendanceModel>();

            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_GetAttendances", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@p_start_date", startDate?.Date);
                        command.Parameters.AddWithValue("@p_end_date", endDate?.Date);
                        command.Parameters.AddWithValue("@p_employee_id", employeeId);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                attendances.Add(MapAttendanceFromReader(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting attendances");
                throw;
            }

            return attendances;
        }

        public async Task<AttendanceModel> GetAttendanceByIdAsync(int id)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_GetAttendanceById", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@p_id", id);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                return MapAttendanceFromReader(reader);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting attendance with ID {id}");
                throw;
            }

            return null;
        }

        public async Task<AttendanceModel> GetAttendanceByDateAsync(int employeeId, DateTime date)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_GetAttendanceByDate", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@p_employee_id", employeeId);
                        command.Parameters.AddWithValue("@p_date", date.Date);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                return MapAttendanceFromReader(reader);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting attendance for employee {employeeId} on date {date:yyyy-MM-dd}");
                throw;
            }

            return null;
        }

        public async Task<IEnumerable<AttendanceModel>> GetAttendancesByEmployeeAsync(int employeeId, DateTime? startDate, DateTime? endDate)
        {
            var attendances = new List<AttendanceModel>();

            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_GetAttendancesByEmployee", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@p_employee_id", employeeId);
                        command.Parameters.AddWithValue("@p_start_date", startDate?.Date);
                        command.Parameters.AddWithValue("@p_end_date", endDate?.Date);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                attendances.Add(MapAttendanceFromReader(reader));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting attendances for employee {employeeId}");
                throw;
            }

            return attendances;
        }

        public async Task<int> AddAttendanceAsync(AttendanceModel attendance)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_AddAttendance", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@p_employee_id", attendance.EmployeeId);
                        command.Parameters.AddWithValue("@p_date", attendance.Date.Date);
                        command.Parameters.AddWithValue("@p_time_in", attendance.TimeIn);
                        command.Parameters.AddWithValue("@p_time_out", attendance.TimeOut);
                        command.Parameters.AddWithValue("@p_hours_worked", attendance.HoursWorked);
                        command.Parameters.AddWithValue("@p_status", attendance.Status);

                        var newIdParam = new MySqlParameter("@p_new_id", MySqlDbType.Int32)
                        {
                            Direction = ParameterDirection.Output
                        };
                        command.Parameters.Add(newIdParam);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        await command.ExecuteNonQueryAsync();

                        return Convert.ToInt32(newIdParam.Value);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding attendance");
                throw;
            }
        }

        public async Task<bool> UpdateAttendanceAsync(AttendanceModel attendance)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_UpdateAttendance", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@p_id", attendance.Id);
                        command.Parameters.AddWithValue("@p_employee_id", attendance.EmployeeId);
                        command.Parameters.AddWithValue("@p_date", attendance.Date.Date);
                        command.Parameters.AddWithValue("@p_time_in", attendance.TimeIn);
                        command.Parameters.AddWithValue("@p_time_out", attendance.TimeOut);
                        command.Parameters.AddWithValue("@p_hours_worked", attendance.HoursWorked);
                        command.Parameters.AddWithValue("@p_status", attendance.Status);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating attendance with ID {attendance.Id}");
                throw;
            }
        }

        public async Task<bool> DeleteAttendanceAsync(int id)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_DeleteAttendance", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@p_id", id);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        var rowsAffected = await command.ExecuteNonQueryAsync();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting attendance with ID {id}");
                throw;
            }
        }

        public async Task<AttendanceSummaryDto> GetAttendanceSummaryAsync(int employeeId, DateTime startDate, DateTime endDate)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_GetAttendanceSummary", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@p_employee_id", employeeId);
                        command.Parameters.AddWithValue("@p_start_date", startDate.Date);
                        command.Parameters.AddWithValue("@p_end_date", endDate.Date);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                return new AttendanceSummaryDto
                                {
                                    TotalRecords = reader.GetInt32("TotalRecords"),
                                    PresentDays = reader.GetInt32("PresentDays"),
                                    AbsentDays = reader.GetInt32("AbsentDays"),
                                    LateDays = reader.GetInt32("LateDays"),
                                    LeaveDays = reader.GetInt32("LeaveDays"),
                                    TotalHours = reader.GetDecimal("TotalHours")
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting attendance summary for employee {employeeId}");
                throw;
            }

            return new AttendanceSummaryDto();
        }

        public async Task<IEnumerable<MonthlyAttendanceTrend>> GetMonthlyAttendanceTrendsAsync(int employeeId, int months)
        {
            var trends = new List<MonthlyAttendanceTrend>();

            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_GetMonthlyAttendanceTrends", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@p_employee_id", employeeId);
                        command.Parameters.AddWithValue("@p_months", months);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                trends.Add(new MonthlyAttendanceTrend
                                {
                                    Year = reader.GetInt32("Year"),
                                    Month = reader.GetInt32("Month"),
                                    TotalDays = reader.GetInt32("TotalDays"),
                                    PresentDays = reader.GetInt32("PresentDays"),
                                    AbsentDays = reader.GetInt32("AbsentDays"),
                                    LateDays = reader.GetInt32("LateDays"),
                                    TotalHours = reader.GetDecimal("TotalHours")
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting monthly attendance trends for employee {employeeId}");
                throw;
            }

            return trends;
        }

        public async Task<bool> CanCheckInAsync(int employeeId, DateTime date)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_CanCheckIn", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@p_employee_id", employeeId);
                        command.Parameters.AddWithValue("@p_date", date.Date);

                        var canCheckInParam = new MySqlParameter("@p_can_check_in", MySqlDbType.Bit)
                        {
                            Direction = ParameterDirection.Output
                        };
                        command.Parameters.Add(canCheckInParam);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        await command.ExecuteNonQueryAsync();

                        return Convert.ToBoolean(canCheckInParam.Value);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error checking if employee {employeeId} can check in on {date:yyyy-MM-dd}");
                throw;
            }
        }

        public async Task<bool> CanCheckOutAsync(int employeeId, DateTime date)
        {
            try
            {
                using (var connection = _databaseConnection.GetConnection())
                {
                    using (var command = new MySqlCommand("sp_CanCheckOut", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@p_employee_id", employeeId);
                        command.Parameters.AddWithValue("@p_date", date.Date);

                        var canCheckOutParam = new MySqlParameter("@p_can_check_out", MySqlDbType.Bit)
                        {
                            Direction = ParameterDirection.Output
                        };
                        command.Parameters.Add(canCheckOutParam);

                        if (connection.State != ConnectionState.Open)
                            await connection.OpenAsync();

                        await command.ExecuteNonQueryAsync();

                        return Convert.ToBoolean(canCheckOutParam.Value);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error checking if employee {employeeId} can check out on {date:yyyy-MM-dd}");
                throw;
            }
        }

        private AttendanceModel MapAttendanceFromReader(DbDataReader reader)
        {
            return new AttendanceModel
            {
                Id = reader.GetInt32("Id"),
                EmployeeId = reader.GetInt32("EmployeeId"),
                Date = reader.GetDateTime("Date"),
                TimeIn = reader.IsDBNull("TimeIn") ? null : reader.GetDateTime("TimeIn"),
                TimeOut = reader.IsDBNull("TimeOut") ? null : reader.GetDateTime("TimeOut"),
                HoursWorked = reader.GetDecimal("HoursWorked"),
                Status = reader.GetString("Status"),
                EmployeeName = $"{reader.GetString("FirstName")} {reader.GetString("LastName")}",
                Department = reader.GetString("Department")
            };
        }
    }
}
