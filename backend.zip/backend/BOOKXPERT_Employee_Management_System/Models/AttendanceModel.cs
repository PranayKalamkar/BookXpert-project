﻿using System.ComponentModel.DataAnnotations;

namespace BOOKXPERT_Employee_Management_System.Models
{
    public class AttendanceModel
    {
        public int Id { get; set; } = 0;
        public int EmployeeId { get; set; } = 0;
        public DateTime Date { get; set; } = DateTime.Now;
        public DateTime? TimeIn { get; set; } = DateTime.Now;
        public DateTime? TimeOut { get; set; } = DateTime.Now;
        public decimal HoursWorked { get; set; } = 0;
        public string Status { get; set; } = string.Empty;
        public string EmployeeName { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;

    }

    public class AttendanceDto
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public DateTime Date { get; set; }
        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public decimal HoursWorked { get; set; }
        public string Status { get; set; }
    }

    public class AttendanceCreateDto
    {
        [Required]
        public int EmployeeId { get; set; }

        [Required]
        public DateTime Date { get; set; }

        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public decimal HoursWorked { get; set; }

        [Required]
        public string Status { get; set; }
    }

    public class AttendanceUpdateDto
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public int EmployeeId { get; set; }

        [Required]
        public DateTime Date { get; set; }

        public DateTime? TimeIn { get; set; }
        public DateTime? TimeOut { get; set; }
        public decimal HoursWorked { get; set; }

        [Required]
        public string Status { get; set; }
    }

    public class CheckInRequest
    {
        [Required]
        public int EmployeeId { get; set; }
    }

    public class CheckOutRequest
    {
        [Required]
        public int EmployeeId { get; set; }
    }

    public class AttendanceSummaryDto
    {
        public int TotalRecords { get; set; }
        public int PresentDays { get; set; }
        public int AbsentDays { get; set; }
        public int LateDays { get; set; }
        public int LeaveDays { get; set; }
        public decimal TotalHours { get; set; }
    }

    public class MonthlyAttendanceTrend
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public int TotalDays { get; set; }
        public int PresentDays { get; set; }
        public int AbsentDays { get; set; }
        public int LateDays { get; set; }
        public decimal TotalHours { get; set; }
    }
}
