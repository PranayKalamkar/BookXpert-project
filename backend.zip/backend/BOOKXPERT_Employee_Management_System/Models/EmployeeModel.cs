﻿namespace BOOKXPERT_Employee_Management_System.Models
{
    public class EmployeeModel
    {
        public int Id { get; set; } = 0;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DateTime DateOfBirth { get; set; } = DateTime.Now;
        public DateTime HireDate { get; set; } = DateTime.Now;
        public string Department { get; set; } = string.Empty;
        public string Position { get; set; } = string.Empty;
        public double Salary { get; set; } = 0;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime? UpdatedAt { get; set; } = DateTime.Now;
    }

    public class DepartmentStats
    {
        public string Department { get; set; }
        public int EmployeeCount { get; set; }
        public decimal AverageSalary { get; set; }
        public decimal TotalSalary { get; set; }
    }

    public class HiringTrend
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public int HireCount { get; set; }
    }
}
