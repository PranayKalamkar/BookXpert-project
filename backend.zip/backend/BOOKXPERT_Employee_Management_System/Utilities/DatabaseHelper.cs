﻿using MySql.Data.MySqlClient;
using System.Data;

namespace BOOKXPERT_Employee_Management_System.Utilities
{
    public static class DatabaseHelper
    {
        public static async Task<int> ExecuteNonQueryAsync(string query, MySqlConnection connection, params MySqlParameter[] parameters)
        {
            using (var command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddRange(parameters);

                if (connection.State != ConnectionState.Open)
                    await connection.OpenAsync();

                return await command.ExecuteNonQueryAsync();
            }
        }

        public static async Task<object> ExecuteScalarAsync(string query, MySqlConnection connection, params MySqlParameter[] parameters)
        {
            using (var command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddRange(parameters);

                if (connection.State != ConnectionState.Open)
                    await connection.OpenAsync();

                return await command.ExecuteScalarAsync();
            }
        }

        public static async Task<MySqlDataReader> ExecuteReaderAsync(string query, MySqlConnection connection, params MySqlParameter[] parameters)
        {
            using (var command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddRange(parameters);

                if (connection.State != ConnectionState.Open)
                    await connection.OpenAsync();

                return await command.ExecuteReaderAsync(CommandBehavior.CloseConnection);
            }
        }
    }
}
